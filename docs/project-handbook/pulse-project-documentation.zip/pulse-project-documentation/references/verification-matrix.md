> Снимок документа 22.10.2026. Источник: `pulse-backend/docs/verification-matrix.md`; связь и владелец — `inventory/snapshot-sources.json`. Ссылки локализованы для автономного пакета.

# Проверки Pulse и обязательные gates — DOC-05

## Q1/F2 · source и bounded runtime evidence, 21.10.2026

[Q1 proof/runbook](q1-runtime.md) фиксирует exact source/binary identities,
обязательные commands, API-only resource proof и отдельную physical fault matrix.
Source DB/SW и narrow execution_busy fix APPROVED тем же Senior. Full check /
isolated integration / build PASS до busy delta; scoped adapter/service race и vet
после delta PASS; post-busy paired binaries rebuilt/build PASS. Финальные full check/integration gates после delta — отдельная запись
в proof. Старый physical stale-zombie FAIL сохраняется; source fix сам по себе его
не закрывает. Frontend source/controlled browser approval не заменяет actual API QA.
Никакой whole-Q1/F2, real-private, production/SLA или scientific acceptance из этих
частичных результатов не выводится.


Q0 RUN-2 ·21.10.2026: [постоянный proof/runbook](q0-runtime.md) фиксирует source/binary/pin identity и **13/13 synthetic runtime PASS**: resource8, replay1, strict faults4. Test names: `TestQ0StoredFileResourceCaps`, `TestQ0StoredFileProcessReplay`, `TestQ0StoredFileProcessFaults` в `internal/transport/httpapi/file_inputs_process_test.go`; generator/launcher — `test/q0_process/`. Без `Q0_PROCESS_RUN=1`, отдельной PG, accepted Python/pin или Darwin measurement profile process SKIP/отсутствие evidence не является acceptance. Историческая Q0 source/runtime/reproducer и final docs/publication ACCEPTED; cold install UNTESTED, remote SDK/CI OPEN, scientific user-deferred/not_assessed. Прежние STOP/RERUN1 FAIL сохранены отдельно от актуального RUN-2.
Срез 19.10.2026. Владелец матрицы — tech-lead; владельцы команд — сопровождающие соответствующих модулей. Команды выполняются из корня указанного репозитория. Эта матрица различает требуемую проверку, настроенный CI и фактически полученное свидетельство. Наличие workflow не означает, что он уже исполнялся на текущем diff.

## Обязательные проверки

| Модуль и окружение | Проверка перед приёмкой | Настроенный CI | Ручная часть и SKIP |
|---|---|---|---|
| Backend: Go ≥1.25 по go.mod, SDK contracts 0.1.2 local UNRELEASED (исторический PREP0.1.1 отдельно), отдельная PostgreSQL 16 | `make check`; `TEST_DATABASE_URL=... make integration`; `make build`. `make fmt` исправляет код, для контроля форматирования используется проверка gofmt из make check | GitHub: gofmt, race tests, vet, сборка api/migrate; тот же job использует отдельный сервис PG. GitLab: race tests/vet с PG. Make build дополнительно проверяет adminuser/cohort/worker | Без тестовой PG integration не принят, даже если прямой go test вывел SKIP. Рабочую БД esp_app не использовать. Проверки реального источника, браузерных прав и восстановления выделяются отдельно |
| Frontend: Node 22 (для тестов минимум 22.18), package-lock | `npm ci`; `npm test`; `npm run build` (TypeScript + Vite) | GitHub и GitLab: install → **npm test → build**; ошибка теста останавливает job, ignore-failure не задан | Для этих тестов модель/БД не нужны: отсутствие модели не основание для SKIP. Визуальная сверка с Figma, клавиатура, обе темы и браузерные сценарии проверяются отдельно |
| Data: Python3.13 в CI, model exact source SHA из PREP manifest; workspace `.venv` общий | `.venv/bin/python -m pytest`; `.venv/bin/python -m pip wheel --no-deps . -w dist` | GitHub: установка pinned model, test, build/twine check. Отдельного GitLab workflow в текущем репозитории нет | Офлайн-регрессия парсера не требует UNITEK/ARMITS credentials. Живой сбор — отдельная разрешённая проверка; не смешивать его пропуск с пропуском офлайн-тестов |
| Model: Python 3.13 в CI, test/deep-learning extras для объявленного набора | `.venv/bin/python -m pytest`; `.venv/bin/python -m pip wheel --no-deps . -w dist` | GitHub: pytest с JUnit, build/twine check. GitLab: pytest и wheel | Если необязательный extra отсутствует, конкретный SKIP и причина фиксируются. Успех unit suite не подтверждает ML-качество; причинная оценка eval_honest.py и закрытый test — отдельная ML-приёмка. Обучение не запускается ради этого документа |
| ML service: Python 3.13 в CI, совместимые model/contracts; runtime profile по отдельной инструкции | `.venv/bin/python -m pytest`; `.venv/bin/python -m pip wheel --no-deps . -w dist`; отдельный smoke установки и Health | GitHub: pinned model/contracts, pytest с JUnit, build/twine check. GitLab: установка зависимостей из заданных refs и pytest. CI/Docker применяют runtime constraints при первоначальной установке model/contracts/service; затем pip check | Artifact-dependent SKIP допустим только как «проверка с моделью не выполнена». Model-free gRPC/probe тесты обязательны. Без exact model/cache/manifest/PG не заявлять успешные Score/Upload или промышленную готовность |
| Contracts: Go ≥1.24 по go.mod, Python 3.13 в CI, Buf/plugins по Makefile | `make lint`; `make breaking BASELINE='.git#ref=<base-sha>'`; `make test`. Генерация/check выполняются в отдельном чистом checkout | GitHub: make tools/check, Go/Python tests, wheel. Breaking относительно PR-base выполняется **только для pull_request**; push/tag/manual автоматически его не проверяют | Для прочих запусков breaking выполняется отдельно с зафиксированным base-sha до приёмки изменения контракта. `make check` перегенерирует gen и проверяет diff; не запускать поверх чужих изменений ради документационного аудита. Нет baseline/Buf/доступа к SDK — gate не пройден; SKIP не заменяет breaking-проверку |
| Landing: Python 3.13 в CI; runtime-зависимости приложения не нужны | `python3 build.py`; проверить dist/index.html и отсутствие необработанных placeholder | GitHub: build, проверка HTML/встроенного SVG и artifact. GitLab: build и artifact | Визуальный QA desktop/mobile и reduced motion отдельно; сборка не проверяет отправку писем, ML или интеграции — лендинг их не выполняет |

Источники команд и CI: [backend Makefile](../inventory/pulse-backend--Makefile), [frontend package.json](../inventory/pulse-frontend--package.json), [model Makefile](../inventory/pulse-model--Makefile), [data Makefile](../inventory/pulse-data--Makefile), [ML README](ml-service-readme.md), [contracts Makefile](../inventory/pulse-contracts--Makefile), landing build.py (исходник `pulse-landing/build.py`; в пакет не включён). Для CI источником является `.github/workflows/ci.yml` и, где существует, `.gitlab-ci.yml` каждого модуля.

## Свидетельства текущей очереди A

| Проверка | Результат | Граница свидетельства |
|---|---|---|
| Frontend `npm test`, 19.10.2026, текущий рабочий diff | PASS, 11 тестов, 0 SKIP | Локальный прогон координатора. Cloud CI после изменения workflow здесь не запускался |
| Frontend `npm run build`, 19.10.2026 | PASS, TypeScript/Vite; предупреждение о размере vendor chunks | Сборка локальная, не публикация сайта. Предупреждение не является ошибкой сборки |
| Model suite DOC-01, 19.10.2026 | PASS, 295 тестов по отчёту исполнителя; финальный acceptance regression повторён координатором: 1 PASS | Suite проверяет реализацию; научная приёмка этим не проведена. Существующие deprecation warnings отражены в отчёте |
| ML probe DOC-03, повторная проверка 19.10.2026 | PASS: 31 targeted/native RPC/CLI tests независимо senior; 4 malformed-key CLI случая дополнительно проверены координатором | Printable ASCII без trim; корректный ключ с пробелами проходит настоящий gRPC. R-DOC03 CLOSED; установленный probe hash совпал, scoped review APPROVE. Profiles не переключались; loopback RPC не доказывают Docker image build |
| Native runtime DOC-06, повторная проверка нового service wheel 19.10.2026 | PASS по отчёту исполнителя: clean venv **57 passed / 1 production-artifact test deselected**, shared suite **58 passed**; 9 pins/pip check/isolation, wheels/source hashes сохранены | Новый service wheel после printable-key/no-echo fix. Wheel SHA256 214b4bc37550e42d8e00d6f064282bc488ec73a1d80eae1c7cd2192246ccb122; source tree e14bc4481ed486c62816af0df9959841e5296b9af700292d5b2a2216879bc96c. Final source/wheel/freeze hash verdict senior APPROVE; 11/11 handoff source hashes дополнительно сверены tech-lead. macOS/arm64 CPython3.13; Score/Upload/PG и Linux/Docker здесь не подтверждены |
| Документационные tools DOC-07, 19.10.2026 | PASS: 14 fixture regressions, включая source/parent/target alias на dummy private paths и no-partial-writes; независимый core review APPROVE, R-DOC07-01 CLOSED; финальная generated-приёмка APPROVE после DOC-03/06 | Источники/новый файл/копия drift, explicit snapshot date, missing/stale checksums, ZIP bytes/file-set/traversal, extracted package без workspace. Общее финальное review очереди A завершено и принято; это историческое свидетельство, не новый PREP publication gate |
| Прочие прогоны очереди A | Актуальные результаты и ограничения записываются в журнал исполнения (локальный архив задач: `../tasks/pulse-backend/docs/documentation-queue-a-execution-2026-10-19.md`) | Отсутствие свежего результата означает «не проверено в этом проходе», а не PASS |

Исторические свидетельства из [главы качества handbook](../chapters/16-quality.md) остаются датированными записями прежнего прохода. Они не подтверждают новый diff или весь набор семи модулей автоматически.

## Правило приёмки и публикации

В результате проверки записывают ID задачи, базу/состав diff, runtime, команду, дату, exit code и counts passed/failed/skipped с причинами. Для внешнего CI сохраняют ссылку на конкретный job; если он не запускался, так и указывают. JUnit, локальный лог или подписанный результат сопровождают проверяемый diff, а не только имя ветки. Ветку с незакоммиченными изменениями нельзя восстановить одним HEAD.

Обязательная проверка с ошибкой или пропущенной зависимостью остаётся открытой. Допустимый SKIP относится к конкретному опциональному сценарию и не расширяется на весь gate. Нельзя подменять отсутствие результатов зелёной общей надписью. Перед изменением protobuf/SDK/миграций нужны соответствующие контрактные и integration проверки; очередь A таких изменений не выполняет.

Обновление этой матрицы требуется при изменении Makefile, package scripts, CI, runtime profile или условия SKIP. DOC-07 связывает её с README и автономным handbook. Согласованный аудит (локальный архив задач: `../tasks/pulse-backend/docs/documentation-audit-2026-10-19.md`) сохраняет исходные находки, журнал — результаты их устранения.

## PREP — текущие свидетельства, отдельные от очереди A

Статус документа: финальная техническая сверка20.10.2026. Нижеследующие результаты прочитаны техлидом в отчётах исполнителей/независимого Senior; это не повтор suite техлидом. PREP-01–07 технически приняты, scientific acceptance user-deferred/not_assessed; финальная публикация handbook выделена отдельным gate в [PREP ledger](readiness-ledger.md).

| Gate / команда | Полученное свидетельство | Предел / оставшийся gate |
|---|---|---|
| Contracts `make lint`, `make breaking BASELINE='.git#ref=f5d51b6'`, official generate, `make test` | P1 Senior clean; wire additive, повтор generate без drift, Go/Python presence/null/int64 checks PASS | Exact source contracts07213c430318affd140f55dea391cdc36220d93f; package0.1.1 не новый release |
| ML `../.venv/bin/python -m pytest -q` | 78PASS; отдельный clean native wheels JUnit78/0skip, pip check; fresh Linux image78PASS6.95s | Не новая precision/recall; bundle-only Upload software gate отдельно от research Score |
| Model `python -m pytest`; P7 `tests/evaluation/test_readiness.py` | Full355PASS по логу исполнителя; Senior targeted60PASS, оба замечания CLOSED | Валидатор метаданных не проверяет raw truth/физическое месторождение; scientific acceptance user-deferred/not_assessed |
| Data Linux fresh constrained image | 32testsPASS0.62s, install/pip check | Synthetic emulator не контрольная ML когорта |
| Backend `make check`, `make build`, `TEST_DATABASE_URL=<isolated pulse_test> make integration` | Fix1 frozen38files: check/build всех4CLI PASS; полная race integration67.610sPASS | Senior F1–F3 CLOSED:10targetedPG/race18.271s+lease1.989sPASS,38/38hashes; старые70.506/68.932s не переносятся на новый diff |
| Frontend Node22 `npm test`, `npm run build` | Первые3Senior findings CLOSED;29testsPASS; bounded responsive followup30tests/buildPASS | Responsive Senior sourcePASS14aggregate/6fix hashes и6/6SSR tests; реальный browser GREEN22/22,fail0/pageErrors0,14/14source hashes на rebuilt image |
| P0 config/CI source profile | Senior ACCEPTED21files; native model103/contracts4/ML12 hashes и50wheel hashes сверены | Backend Senior staged-source223files ACCEPTED; все7payload commits в compatibility manifest, frozen backend38точны; docs-only потомок отдельно |
| Реальный isolated8088/8018 | API→Data→ML, auth/scope/Excel/logout/Origin и сохранённый snapshot после restart PASS по координатору; run30/31=100scored, run32=98scored/1archived/1inactive | Рабочий8080 не менялся. Lifecycle fixture восстановлен, browser GREEN22/22; after11run33 done100scored с правильной identity, snapshots30/32 неизменны, restricted0 |
| Cloud GitHub/GitLab | Конфиги exact source refs+constraints проверены локально | Cloud jobs/push не выполнялись; remote наличие local commits не заявлено |

Go/ML/Data consumer CI фиксирует contracts07213c430318affd140f55dea391cdc36220d93f и model f5c2a3de031ff4794194a219f048c9bf8c7c4f45 там, где применимо. GitLab fetch точного SHA с checkout detached и проверкой HEAD; `clone --branch <SHA>` не используется. Конфигурация не делает локальный commit доступным remote. [Финальный compatibility manifest](../inventory/readiness-compatibility.json) фиксирует все7reviewed payload commits и image IDs. Backend ref — runtime payload99b7fa3d; финальный README/docs-only потомок не меняет этот runtime ref и не создаёт hash-самоссылку.

Migration11 runtime: первое/повторное применение exit0; прежние значения5таблиц и immutable snapshot digests сохранены по coordinator migration11-evidence.json. Все4финальных images подняты с health wait. Lifecycle fixture восстановлен через API revisions; after11run33 done/profilecohort/versionpresentation-v1:100members/100scored,0error; historical30/32 unchanged, restricted0.

`runtime-image-binding.json`:4actual image IDs связаны с source manifests; семь численных ML/Data versions совпадают, pip check обоих PASS. Backend image имеет no_container_healthcheck: HTTP Health200 проверен отдельно, поэтому общий Health не выводится из Docker healthy.

Техническая приёмка PREP завершена; [native artifact manifest](../inventory/readiness-native-artifacts.json) сохраняет119source/50wheel hashes. Остался отдельный публикационный gate: final handbook sync/build/check/validate/extractedZIP и docs-only commit координатора. Научный/промышленный/cloud gate этим не закрывается.
