# Аутентификация RBAC и защита данных

Q1 synthetic admission и все private reads/reviews проверяют current owner account,
роль technologist/admin, well/cohort и server-owned manifest/PG guard. Другой admin
не читает чужой file check; viewer сохраняет legacy period reads. Worker доверяет
persisted intent/PG auth, не browser cookie/actor из broker. Транзакционные locks,
lease token hash и fence защищают execution/finalization; поздний stale result
не принимается. `FILE_CHECK_MODE=off` default, `FILE_CHECK_ALLOW_REAL=true` — startup
error. [Протокол](../references/q1-file-jobs.md), [proof](../references/q1-runtime.md).
Обычная ролевая таблица ниже относится к legacy/period объектам, не расширяет
owner-only private files. Secrets/payload/tokens в status/broker/logs отсутствуют.


Q0 saved path получает actor только из current session/account, заново проверяет role/scope/lifecycle на prepare/accept/open/result/retry/compute; saved snapshot не capability. Public payload JSON скрыт, list/metadata payload-free. [RUN-2](../references/q0-runtime.md) проверил эти synthetic controls и fail-closed faults до features. Real-private enable закрыт до owner TTL/max lifetime, encryption PG/WAL/temp/backups, access/audit, quotas/retention/backup policy; synthetic PASS не разрешает реальные файлы.
## Два режима запуска

| Режим | Идентификация | Назначение |
|---|---|---|
| legacy | Общий локальный principal; опциональный API key | Совместимость и локальное тестирование |
| local | Логин/пароль, серверный сеанс, персональный Principal | Роли, scope, проверяемый автор действий |

Дополнение PREP: изолированный runtime 8088/8018 принят с local sessions и cohort scope. Файл compose.local теперь также задаёт local/cohort; код AUTH_MODE сохраняет legacy compatibility default. Старый уже работающий экземпляр 8080 не переключался. Перед новым запуском нужны явные migrations/bootstrap/capture и cookie/origin; документация не создаёт аккаунты и не меняет действующие секреты.

## Роли и область данных

| Действие | Администратор | Технолог | Наблюдатель |
|---|---|---|---|
| Просмотр разрешённых скважин, риска и телеметрии | Да | Да, по scope | Да, по scope |
| Чтение проверок и предметной истории | Да | Да, по scope | Да, по scope |
| Ручная проверка скважины | Да | Да, по scope | Нет |
| Заключение по проверке/тревоге, регистрация отказа | Да | Да, по scope | Нет |
| Разрешённое редактирование участника/архива | Да, внутри membership | Нет | Нет |
| Настройка источников, глобальный прогон | Да | Нет | Нет |
| Учётные записи, технический аудит, интеграции | Да | Нет | Нет |

Scope задаёт funds, ngdus, departments. Для технолога/наблюдателя фильтры применяются совместно; null означает все разрешённые значения, пустой список не означает «все». В cohort-профиле membership проверяется также для admin: Principal.Allows не даёт обход FundScope. Обычные права пересекаются с membership; прямой foreign ID скрывается как 404. В cohort глобальные NGDU/department mutations запрещены 403 до lookup/store, даже для разрешённого reference и admin; research opt-in сохраняет отдельную семантику. Frontend скрывает недоступные действия, но решающая проверка находится на сервере, включая прямые URL и экспорт.

## Сеансы и пароли

Пароли хранятся как bcrypt cost 12; сеанс использует случайный токен, в БД хранится SHA256 digest. Срок — 8 часов. Cookie HttpOnly/SameSite=Strict, Secure по конфигурации (по умолчанию true). Запросы изменения в local проверяют origin; вход ограничивается по частоте. Смена ревизии/статуса пользователя влияет на его сеансы через серверное хранилище.

Пароль первого администратора передаётся `cmd/adminuser` только через stdin из защищённого источника. Не включайте пароль в аргументы процесса, команды истории shell, Git или документацию. Полноценные самостоятельная регистрация и восстановление пароля существуют в макетах, но не являются работающим публичным onboarding.

## Подключение SSO

Есть `auth_identity(provider_id,subject)` и сервисная граница внешней идентификации. Полный OIDC login/callback, discovery/JWKS, проверка issuer/audience/state/nonce/PKCE и lifecycle токенов ещё не подключены. Целевой IdP — Keycloak или иной OIDC-провайдер; внешняя identity связывается с локальным пользователем, права/scope определяются сервером. Нельзя доверять роли из произвольного браузерного заголовка.

## Секреты и транспорт

Секрет источника шифруется AES-256-GCM. `INTEGRATION_SECRET_KEY` — 32 случайных байта в base64, хранится отдельно от БД. Копия БД без этого ключа не восстанавливает доступ к источникам; потеря/смена ключа требует контролируемой миграции секретов. Пустой secret не требует ключа.

Сетевой ML transport в текущем локальном запуске использует insecure gRPC внутри Docker-сети; при заданном ML_SERVICE_API_KEY проверяется metadata. Это не mTLS. Для удалённого размещения требуется защищённый транспорт/сегментация и управление секретами. Loopback-публикация текущего Compose не является готовой схемой внешнего доступа.

НДА раскрывается в описании источника; реальные телеметрия, номера/сопоставления и манифест не публикуются с лендингом или документацией. Пользовательское название Pulse Connector не изменяет юридическое происхождение данных.

## Свидетельство PREP

Фактический isolated browser/auth gate подтвердил anonymous401, viewer mutation403, forbidden Origin403, logout→401 и повторный вход restricted пользователя без сохранённых admin ссылок/кэша. Scope проверен также на direct ID и Excel; нулевое разрешённое пересечение не превращается в полный фонд. Mobile account/logout и toggle доступны клавиатурой, hidden links исключены из Tab. Это ограниченный runtime gate, не SSO/TLS или полный security/WCAG audit. Даты, отдельные backend/integration и browser результаты — в [PREP ledger](../references/readiness-ledger.md).
